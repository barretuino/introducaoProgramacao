/**
   Exemplo de uma Macro utilizando
   #define: criando um Escreva("Texto")
**/
#include <stdio.h>
#include <stdlib.h>

#define escreva(texto) printf("%s",texto)
#define leia(variavel) scanf("%i", &variavel)
#define cabecalho printf("************\n")

main(){
    cabecalho;
    escreva("Teste de Texto\n");
    cabecalho;
    
    int valor;
    escreva("Informe um valor: ");
    leia(valor);
    printf("O valor informado e %i\n", valor);
    
    system("PAUSE");
}
