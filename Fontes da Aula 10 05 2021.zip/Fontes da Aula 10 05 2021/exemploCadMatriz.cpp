#include <stdio.h>
#include <stdlib.h>
/**
	Exemplo de cadastro com Matrizes
	Prof. Paulo Barreto
	Data 10/05/2021
**/

//Declara��o de forma global a matriz
int matrizCadastro[2][10]; //Respectivamente cod, quantidade
int linha = 0;
int opcao = 0;

//Fun��o de Cadastro
void cadastrar(int codProduto, int quantidade){
	matrizCadastro[0][linha] = codProduto;
	matrizCadastro[1][linha] = quantidade;
	linha++; //linha = linha + 1; //linha += 1;
	printf("Cadastro realizado com sucesso!\n");
}

//Fun��o de Pesquisa
void pesquisar(int codProduto){
	int localizado = 0;
	for(int i=0; i < linha; i++){
		if(matrizCadastro[0][i] == codProduto){
			printf("Localizado: quantidade e %i\n",
				matrizCadastro[1][i]);
				localizado = 1;
		}
	}
	if(localizado == 0){
		printf("Produto N�o localizado, verifique\n");
	}	
}

void menu(){	
	system("cls");
	printf("******* MENU *********\n");
	printf("* 1 - Cadastrar      *\n");
	printf("* 2 - Pesquisar      *\n");
	printf("* 3 - Sair           *\n");
	printf("**********************\n");
	printf("\nEscolha uma op��o: ");
	scanf("%i", &opcao);
}

main(){
	int codProduto;
	int quantidade;
	
	menu();
	do{
		switch (opcao){
			case 1:
				if(linha < 10){	
					printf("Informe o codigo do Produto ");
					scanf("%i", &codProduto);
					printf("Informe a quantidade ");
					scanf("%i", &quantidade);
					
					cadastrar(codProduto, quantidade);
				}else{
					printf("N�o foi possivel inserir novos elementos.");
				}
				system("pause");
				menu();
				break;
			case 2:
				printf("Informe o c�digo a ser pesquisado: ");
				scanf("%i", &codProduto);
				pesquisar(codProduto);
				system("pause");
				menu();
				break;
			case 3:
				printf("Sair do Sistema. Muito Obrigado.\n");
				break;
			default:
				printf("Opcao escolhida inv�lida\n");
				menu();			
		}
	}while(opcao != 3);	
}
