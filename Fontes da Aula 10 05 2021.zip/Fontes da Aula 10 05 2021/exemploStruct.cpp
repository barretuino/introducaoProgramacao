#include <stdio.h>
#include <stdlib.h>

struct Veiculo{
	float valor;
	int kmRodado;	
};
struct Produto{
	int codigo;
	float quantidade;
};

main(){
	struct Produto vetProduto[5];
	vetProduto[0].codigo = 456;
	vetProduto[0].quantidade = 12;

	vetProduto[1].codigo = 753;
	vetProduto[1].quantidade = 245.12;
	
	struct Veiculo meuCarro;
	
	meuCarro.kmRodado = 8900;
	meuCarro.valor = 19900.45;
	
	printf("Km rodado e %i\n", meuCarro.kmRodado);
	printf("Valor e %.2f\n", meuCarro.valor);
}
