#include <stdio.h>
#include <stdlib.h>

//Declara��o de Vari�vel - Global
int valor = 12;
float pi = 3.14;
float taxaCambio = 5.08;

int valorTotal(int valor, int quantidade){
	return valor * quantidade;
}
int valorTotal(int quantidade){
	return valor * quantidade;
}

main(){	
	printf("Valor %i \n", valor);
	printf("Valor Total %i \n", valorTotal(5, 10));
	
	valor = 10;
	printf("Valor Total utilizando valor %i \n",
		valorTotal(10));
}
