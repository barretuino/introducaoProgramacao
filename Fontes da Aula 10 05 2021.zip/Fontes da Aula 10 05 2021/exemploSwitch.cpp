#include <stdio.h>
#include <stdlib.h>

main(){
	int mes = 0;
	printf("Informe o mes que voce nasceu: ");
	scanf("%i", &mes);
	
	switch (mes){
		case 1:
			printf("Nascido em Janeiro\n");
			break;
		case 2:
			printf("Nascido em Fevereiro\n");
			break;
		case 3:
			printf("Nascido em Mar�o\n");
			break;
		case 4:
			printf("Nascido em Abril\n");
			break;
		case 5:
			printf("Nascido em Maio\n");
			break;
		case 6:
			printf("Nascido em Junho\n");
			break;
		case 7:
			printf("Nascido em Julho\n");
			break;
		case 8:
			printf("Nascido em Agosto\n");
			break;		
		case 9:
			printf("Nascido em Setembro\n");
			break;
		case 10:
			printf("Nascido em Outubro\n");
			break;
		case 11:
			printf("Nascido em Novembro\n");
			break;
		case 12:
			printf("Nascido em Dezembro\n");
			break;
		default:
			printf("O mes informado � invalido\n");
	}
}
